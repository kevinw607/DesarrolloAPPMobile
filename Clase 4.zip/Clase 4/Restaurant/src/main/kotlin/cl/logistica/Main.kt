package org.example.cl.logistica

import cl.logistica.EstadoPedido
import cl.logistica.Pedido
import cl.logistica.ProcesadorPedido
import kotlin.system.measureTimeMillis
import kotlinx.coroutines.runBlocking

fun mostrarEstado(estado: EstadoPedido){
    when (estado) {
        EstadoPedido.Cargando ->
            println("Estado: procesando pedido.....")
        
        is EstadoPedido.Exito ->
            println("Estado: ${estado.mensaje}")
        
        is EstadoPedido.Error ->
            println("Estado: ${estado.motivo}")
    }
}
//Declarar RunBlocking para poder trabajar con corrutinas en el Main
fun main() = runBlocking {
    
    println("BIENVENIDOS A RESTAURANTE LA OLLA")
    //APPLY = CREAR Y DEVOLVER UN OBJETO
    val pedido = Pedido(
        id = "PED-34876546",
        producto = "Pollito con papas",
        cantidad = 3,
        emailCliente = "lolexoalv@gmail.com"
    ).apply { 
        envioExpress = true
    }
    println("Pedido creado con Apply : ${pedido}")

    //let se ejecuta solo si hay un valor
    pedido.emailCliente?.let { email ->
        println("Confirmacion de pedido eviada al correo: ${email}")
    }
    mostrarEstado(EstadoPedido.Cargando)

    val tiempo = measureTimeMillis {
        val estadoFinal = ProcesadorPedido.procesar(pedido)
        mostrarEstado(estadoFinal)
    }

    println("Tiempo total del programa : $tiempo en milisegundos")
}