package cl.logistica

import kotlinx.coroutines.async

import kotlinx.coroutines.coroutineScope

import kotlinx.coroutines.delay


object ProcesadorPedido {

    //Stock

    private suspend fun consultarStock(pedido: Pedido): Boolean {

        println("Consultando el stock...")

        delay(10_000)

        return pedido.cantidad <=5

    }

    //Procesar el pago

    private suspend fun autorizarPago(): Boolean{

        println("Autorizando pago...")

        delay(5_000)

        return true

    }


    //CoroutineScope = analizar el flujo

    suspend fun procesar(pedido: Pedido): EstadoPedido = coroutineScope {



        val stockPendiente = async {

            consultarStock(pedido)

        }



        val pagoPendiente = async {

            autorizarPago()

        }



        //valores que van a esperar el resultado

        val hayStock = stockPendiente.await()

        val pagoAprobado = pagoPendiente.await()

        //Retornar

        when {

            !hayStock ->

                EstadoPedido.Error("No existe el stock suficiente para preparar el pedido")

            !pagoAprobado ->

                EstadoPedido.Error("El pago fué rechazado, saldo insuficiente")

            else ->

                EstadoPedido.Exito("Pedido ${pedido.id} aprobado correctamente")

        }


    }

}