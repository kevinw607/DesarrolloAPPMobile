package cl.logistica



sealed class EstadoPedido {

    object Cargando : EstadoPedido()

    //estados del pedido

    data class Exito(val mensaje: String) : EstadoPedido()

    data class Error(val motivo: String) : EstadoPedido()

}