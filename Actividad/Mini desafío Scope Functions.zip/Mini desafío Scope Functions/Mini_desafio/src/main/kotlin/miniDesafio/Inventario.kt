package org.example.miniDesafio

class Inventario {
    val listaArticulos = mutableListOf<Articulo>()

    fun agregarArticulo(articulo: Articulo) {
        listaArticulos.add(articulo)
    }

    fun buscarPorCodigo(codigo: String): Articulo? {
        return listaArticulos.find { it.codigo == codigo }
    }

    fun obtenerTotalArticulos(): Int = listaArticulos.sumOf { it.stock }

    fun obtenerValorTotal(): Double = listaArticulos.sumOf { it.precio * it.stock }
}