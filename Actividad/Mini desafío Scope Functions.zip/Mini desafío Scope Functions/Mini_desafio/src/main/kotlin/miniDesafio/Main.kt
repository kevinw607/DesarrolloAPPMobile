package org.example.miniDesafio

fun main() {
    val puertoGames = Inventario()

    val nuevoArticulo = Articulo().apply {
        codigo = "A002"
        nombre = "Audifonos Gamer"
        categoria = "Accesorio"
        precio = 49990.0
        stock = 5
    }.also {
        println("Articulo registrado: ${it.nombre}")
    }

    puertoGames.agregarArticulo(nuevoArticulo)

    puertoGames.buscarPorCodigo("A002")?.let { articulo ->

        articulo.vender(2)

        val mensajeVenta = articulo.run {
            "Venta realizada: $nombre\nStock restante: $stock"
        }
        println(mensajeVenta)
    }

    with(puertoGames) {
        println("Cantidad total de articulos: ${obtenerTotalArticulos()}")
        println("Valor total del inventario: $$${obtenerValorTotal()}")
    }
}