package org.example.miniDesafio

class Articulo {
    var codigo: String = ""
    var nombre: String = ""
    var categoria: String = ""
    var precio: Double = 0.0
    var stock: Int = 0

    fun vender(cantidad: Int) {
        if (cantidad <= stock) {
            stock -= cantidad
        }
    }
}